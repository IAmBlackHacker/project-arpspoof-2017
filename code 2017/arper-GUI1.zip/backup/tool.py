from bin import arpd
var=Sniffer()
while True:
	var.sniff_packet()
