from arpd import Sniffer
var=Sniffer()
while True:
	var.sniff_packet()
